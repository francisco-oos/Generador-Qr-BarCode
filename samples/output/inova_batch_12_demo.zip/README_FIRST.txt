SERVER OFICINA MARKING STUDIO
1) batch.svg: recomendado para LightBurn o Sculpfun Space (vector).
2) batch_300dpi.png: alternativa raster para LaserGRBL u otros flujos compatibles.
3) preview/preview_DO_NOT_ENGRAVE.svg contiene la geometría de la base SOLO para revisión.
4) batch.svg y el PNG de engraving/ contienen únicamente las marcas.
5) Antes de grabar sobre equipo real, ejecute una prueba física en material de descarte y valide con el lector real.
